<?php
	$conn = new mysqli("localhost", "root", "", "sist_hot") or die(mysqli_error());
